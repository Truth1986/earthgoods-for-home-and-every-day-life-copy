import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Leaf, ArrowLeft, Plus, Trash2, ShoppingCart, ChefHat, Pencil, Check } from "lucide-react";
import { Link } from "react-router-dom";
import RecipePicker from "@/components/mealplan/RecipePicker";
import ShoppingList from "@/components/mealplan/ShoppingList";
import { toast } from "sonner";

export default function MealPlanner() {
  const queryClient = useQueryClient();
  const [activePlanId, setActivePlanId] = useState(null);
  const [newPlanName, setNewPlanName] = useState('');
  const [creatingNew, setCreatingNew] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me().catch(() => null),
  });

  const { data: mealPlans = [], isLoading: plansLoading } = useQuery({
    queryKey: ['meal-plans', user?.email],
    queryFn: () => base44.entities.MealPlan.list('-created_date'),
    enabled: !!user?.email,
  });

  const { data: recipes = [], isLoading: recipesLoading } = useQuery({
    queryKey: ['recipes-published'],
    queryFn: () => base44.entities.Recipe.filter({ status: 'published' }, 'title'),
  });

  const activePlan = mealPlans.find(p => p.id === activePlanId) || mealPlans[0] || null;

  const createPlan = useMutation({
    mutationFn: (name) => base44.entities.MealPlan.create({ name, recipe_ids: [], checked_ingredients: [] }),
    onSuccess: (plan) => {
      queryClient.invalidateQueries({ queryKey: ['meal-plans'] });
      setActivePlanId(plan.id);
      setNewPlanName('');
      setCreatingNew(false);
      toast.success('Meal plan created!');
    },
  });

  const updatePlan = useMutation({
    mutationFn: ({ id, data }) => base44.entities.MealPlan.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['meal-plans'] }),
  });

  const deletePlan = useMutation({
    mutationFn: (id) => base44.entities.MealPlan.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['meal-plans'] });
      setActivePlanId(null);
      toast.success('Plan deleted');
    },
  });

  const toggleRecipe = (recipeId) => {
    if (!activePlan) return;
    const current = activePlan.recipe_ids || [];
    const updated = current.includes(recipeId)
      ? current.filter(id => id !== recipeId)
      : [...current, recipeId];
    updatePlan.mutate({ id: activePlan.id, data: { recipe_ids: updated } });
  };

  const toggleIngredient = (key) => {
    if (!activePlan) return;
    const current = activePlan.checked_ingredients || [];
    const updated = current.includes(key)
      ? current.filter(k => k !== key)
      : [...current, key];
    updatePlan.mutate({ id: activePlan.id, data: { checked_ingredients: updated } });
  };

  const clearChecked = () => {
    if (!activePlan) return;
    updatePlan.mutate({ id: activePlan.id, data: { checked_ingredients: [] } });
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center">
        <div className="text-center">
          <ChefHat className="w-16 h-16 mx-auto text-stone-300 mb-4" />
          <h2 className="text-xl font-bold text-stone-700 mb-2">Sign in to use Meal Planner</h2>
          <p className="text-stone-500 mb-4">Plan your meals and build shopping lists.</p>
          <Button onClick={() => base44.auth.redirectToLogin('/MealPlanner')} className="bg-emerald-600 hover:bg-emerald-700 text-white rounded-full">
            Sign In
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-stone-50 to-amber-50/30">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-stone-100">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-amber-500 flex items-center justify-center">
              <Leaf className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-stone-800">EarthGoods</span>
          </Link>
          <Link to="/Recipes">
            <Button variant="outline" className="rounded-full border-stone-200">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Recipes
            </Button>
          </Link>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-stone-800 mb-1 flex items-center gap-3">
            <ShoppingCart className="w-8 h-8 text-emerald-600" />
            Meal Planner
          </h1>
          <p className="text-stone-500">Select recipes for your meal plan and get a consolidated shopping list.</p>
        </div>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Sidebar: Plans */}
          <aside className="lg:col-span-1">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center justify-between">
                  My Plans
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setCreatingNew(true)}
                    className="h-7 px-2 text-emerald-600"
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-1">
                {creatingNew && (
                  <div className="flex gap-1 mb-2">
                    <Input
                      autoFocus
                      placeholder="Plan name..."
                      value={newPlanName}
                      onChange={e => setNewPlanName(e.target.value)}
                      onKeyDown={e => { if (e.key === 'Enter' && newPlanName.trim()) createPlan.mutate(newPlanName.trim()); }}
                      className="h-8 text-sm"
                    />
                    <Button
                      size="sm"
                      className="h-8 px-2 bg-emerald-600 hover:bg-emerald-700"
                      disabled={!newPlanName.trim()}
                      onClick={() => createPlan.mutate(newPlanName.trim())}
                    >
                      <Check className="w-3 h-3" />
                    </Button>
                  </div>
                )}

                {plansLoading ? (
                  <div className="space-y-2">
                    {[1,2,3].map(i => <div key={i} className="h-10 bg-stone-100 rounded-lg animate-pulse" />)}
                  </div>
                ) : mealPlans.length === 0 && !creatingNew ? (
                  <div className="text-center py-6 text-stone-400 text-sm">
                    <p>No plans yet.</p>
                    <button onClick={() => setCreatingNew(true)} className="text-emerald-600 mt-1 font-medium">Create one</button>
                  </div>
                ) : (
                  mealPlans.map(plan => (
                    <button
                      key={plan.id}
                      onClick={() => setActivePlanId(plan.id)}
                      className={`w-full text-left px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center justify-between group ${
                        activePlan?.id === plan.id
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'hover:bg-stone-100 text-stone-700'
                      }`}
                    >
                      <span className="truncate">{plan.name}</span>
                      <span className="text-xs text-stone-400 flex-shrink-0 ml-1">
                        {plan.recipe_ids?.length || 0} recipes
                      </span>
                    </button>
                  ))
                )}
              </CardContent>
            </Card>
          </aside>

          {/* Main area */}
          {activePlan ? (
            <div className="lg:col-span-3 grid md:grid-cols-2 gap-6">
              {/* Recipe Picker */}
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base flex items-center gap-2">
                      <ChefHat className="w-4 h-4 text-emerald-600" />
                      {activePlan.name}
                      <span className="text-xs font-normal text-stone-400">— pick recipes</span>
                    </CardTitle>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deletePlan.mutate(activePlan.id)}
                      className="h-7 px-2 text-stone-400 hover:text-red-500"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {recipesLoading ? (
                    <div className="space-y-3">
                      {[1,2,3].map(i => <div key={i} className="h-16 bg-stone-100 rounded-xl animate-pulse" />)}
                    </div>
                  ) : (
                    <RecipePicker
                      recipes={recipes}
                      selectedIds={activePlan.recipe_ids || []}
                      onToggle={toggleRecipe}
                    />
                  )}
                </CardContent>
              </Card>

              {/* Shopping List */}
              <Card>
                <CardContent className="pt-6">
                  <ShoppingList
                    recipes={recipes}
                    selectedIds={activePlan.recipe_ids || []}
                    checkedKeys={activePlan.checked_ingredients || []}
                    onToggleCheck={toggleIngredient}
                    onClearChecked={clearChecked}
                  />
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="lg:col-span-3 flex items-center justify-center">
              <div className="text-center py-20">
                <ChefHat className="w-16 h-16 mx-auto text-stone-300 mb-4" />
                <h3 className="text-lg font-semibold text-stone-600 mb-2">No plan selected</h3>
                <p className="text-stone-400 mb-4">Create a new meal plan to get started.</p>
                <Button onClick={() => setCreatingNew(true)} className="bg-emerald-600 hover:bg-emerald-700 text-white rounded-full">
                  <Plus className="w-4 h-4 mr-2" />
                  New Meal Plan
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}