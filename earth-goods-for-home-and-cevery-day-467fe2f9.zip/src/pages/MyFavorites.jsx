import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Leaf, Heart, ChefHat, Trash2, ArrowLeft, Clock } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const categoryColors = {
  homesteading: "bg-amber-100 text-amber-800", baking: "bg-orange-100 text-orange-800",
  preserving: "bg-lime-100 text-lime-800", fermentation: "bg-yellow-100 text-yellow-800",
  gardening: "bg-emerald-100 text-emerald-800", animal_care: "bg-rose-100 text-rose-800",
  herbal: "bg-teal-100 text-teal-800", seasonal: "bg-stone-100 text-stone-800",
};

const categoryLabels = {
  homesteading: "Homesteading", baking: "Baking", preserving: "Preserving",
  fermentation: "Fermentation", gardening: "Gardening", animal_care: "Animal Care",
  herbal: "Herbal", seasonal: "Seasonal",
};

export default function MyFavorites() {
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: favorites = [], isLoading } = useQuery({
    queryKey: ['favorite-recipes', user?.email],
    queryFn: () => base44.entities.FavoriteRecipe.list('-created_date'),
    enabled: !!user?.email,
  });

  const removeMutation = useMutation({
    mutationFn: (id) => base44.entities.FavoriteRecipe.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['favorite-recipes'] }),
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-stone-50 to-amber-50/30">
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-stone-100">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to={createPageUrl('Home')} className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-amber-500 flex items-center justify-center">
              <Leaf className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-stone-800">EarthGoods</span>
          </Link>
          <Link to={createPageUrl('Recipes')}>
            <Button variant="outline" className="rounded-full">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Recipes
            </Button>
          </Link>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 rounded-full bg-rose-100 flex items-center justify-center">
            <Heart className="w-6 h-6 text-rose-500 fill-rose-400" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-stone-800">My Favorites</h1>
            <p className="text-stone-500">{favorites.length} saved recipe{favorites.length !== 1 ? 's' : ''}</p>
          </div>
        </div>

        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map(i => <div key={i} className="bg-white rounded-2xl h-64 animate-pulse" />)}
          </div>
        ) : favorites.length === 0 ? (
          <Card className="bg-white border-stone-200">
            <CardContent className="p-16 text-center">
              <Heart className="w-16 h-16 mx-auto text-stone-300 mb-4" />
              <h3 className="text-xl font-semibold text-stone-700 mb-2">No saved recipes yet</h3>
              <p className="text-stone-500 mb-6">Browse recipes and tap the heart icon to save your favorites</p>
              <Link to={createPageUrl('Recipes')}>
                <Button className="bg-emerald-600 hover:bg-emerald-700 rounded-full">
                  Browse Recipes
                </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {favorites.map(fav => (
              <div key={fav.id} className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-shadow group relative">
                {/* Remove button */}
                <button
                  onClick={() => removeMutation.mutate(fav.id)}
                  className="absolute top-3 right-3 z-10 w-8 h-8 rounded-full bg-white/90 flex items-center justify-center text-stone-400 hover:text-rose-600 hover:bg-rose-50 shadow transition-colors"
                  title="Remove from favorites"
                >
                  <Trash2 className="w-4 h-4" />
                </button>

                <Link to={`/RecipeDetail?slug=${fav.recipe_slug}`}>
                  <div className="h-44 bg-stone-100 overflow-hidden">
                    {fav.recipe_cover_image_url ? (
                      <img
                        src={fav.recipe_cover_image_url}
                        alt={fav.recipe_title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-emerald-100 to-amber-100">
                        <ChefHat className="w-10 h-10 text-emerald-400" />
                      </div>
                    )}
                  </div>
                  <div className="p-5">
                    {fav.recipe_category && (
                      <Badge className={`${categoryColors[fav.recipe_category] || 'bg-stone-100 text-stone-700'} border-0 mb-2`}>
                        {categoryLabels[fav.recipe_category] || fav.recipe_category}
                      </Badge>
                    )}
                    <h3 className="font-bold text-stone-800 group-hover:text-emerald-700 transition-colors line-clamp-2">
                      {fav.recipe_title}
                    </h3>
                  </div>
                </Link>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}