import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Heart } from 'lucide-react';
import { toast } from 'sonner';

export default function FavoriteButton({ recipe, className = '' }) {
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me().catch(() => null),
  });

  const { data: favorites = [] } = useQuery({
    queryKey: ['favorite-recipes', user?.email],
    queryFn: () => base44.entities.FavoriteRecipe.filter({ recipe_id: recipe.id }),
    enabled: !!user?.email,
  });

  const isFavorited = favorites.length > 0;

  const addMutation = useMutation({
    mutationFn: () => base44.entities.FavoriteRecipe.create({
      recipe_id: recipe.id,
      recipe_title: recipe.title,
      recipe_slug: recipe.slug,
      recipe_cover_image_url: recipe.cover_image_url || '',
      recipe_category: recipe.category || '',
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['favorite-recipes'] });
      toast.success('Added to favorites!');
    },
  });

  const removeMutation = useMutation({
    mutationFn: () => base44.entities.FavoriteRecipe.delete(favorites[0].id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['favorite-recipes'] });
      toast.success('Removed from favorites');
    },
  });

  const handleClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user) {
      toast.error('Sign in to save favorites');
      return;
    }
    if (isFavorited) {
      removeMutation.mutate();
    } else {
      addMutation.mutate();
    }
  };

  const isPending = addMutation.isPending || removeMutation.isPending;

  return (
    <button
      onClick={handleClick}
      disabled={isPending}
      className={`flex items-center justify-center w-10 h-10 rounded-full transition-all ${
        isFavorited
          ? 'bg-rose-100 text-rose-600 hover:bg-rose-200'
          : 'bg-white/80 text-stone-400 hover:bg-rose-50 hover:text-rose-500'
      } shadow-sm border border-stone-200 ${className}`}
      title={isFavorited ? 'Remove from favorites' : 'Save to favorites'}
    >
      <Heart className={`w-5 h-5 ${isFavorited ? 'fill-rose-500 text-rose-500' : ''} ${isPending ? 'animate-pulse' : ''}`} />
    </button>
  );
}