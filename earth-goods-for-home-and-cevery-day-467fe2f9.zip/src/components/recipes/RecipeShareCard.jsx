import React, { useState } from 'react';
import { Share2, Copy, Check, X, Facebook, Twitter } from "lucide-react";
import { Button } from "@/components/ui/button";

const platforms = [
  {
    name: "Facebook",
    icon: Facebook,
    color: "bg-[#1877F2] hover:bg-[#166fe5] text-white",
    getUrl: (url, title) =>
      `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
  },
  {
    name: "Twitter / X",
    icon: Twitter,
    color: "bg-[#000] hover:bg-[#222] text-white",
    getUrl: (url, title) =>
      `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(`Check out this recipe: ${title}`)}`,
  },
  {
    name: "Pinterest",
    icon: null,
    color: "bg-[#E60023] hover:bg-[#cc001f] text-white",
    getUrl: (url, title, image) =>
      `https://pinterest.com/pin/create/button/?url=${encodeURIComponent(url)}&description=${encodeURIComponent(title)}&media=${encodeURIComponent(image || '')}`,
    svg: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 0C5.373 0 0 5.373 0 12c0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738a.36.36 0 0 1 .083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.632-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0z"/>
      </svg>
    ),
  },
  {
    name: "WhatsApp",
    icon: null,
    color: "bg-[#25D366] hover:bg-[#20bd5a] text-white",
    getUrl: (url, title) =>
      `https://wa.me/?text=${encodeURIComponent(`${title} - ${url}`)}`,
    svg: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
      </svg>
    ),
  },
];

export default function RecipeShareCard({ recipe }) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const shareUrl = `${window.location.origin}/RecipeDetail?slug=${recipe.slug}`;
  const shareTitle = recipe.title;
  const shareImage = recipe.cover_image_url;

  const handleCopy = async () => {
    await navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = (platform) => {
    const url = platform.getUrl(shareUrl, shareTitle, shareImage);
    window.open(url, '_blank', 'noopener,noreferrer,width=600,height=500');
  };

  // Native share API support
  const canNativeShare = typeof navigator !== 'undefined' && !!navigator.share;

  const handleNativeShare = async () => {
    try {
      await navigator.share({ title: shareTitle, url: shareUrl });
    } catch {}
  };

  return (
    <div className="relative">
      <Button
        variant="outline"
        size="sm"
        onClick={() => setOpen(!open)}
        className="rounded-full border-stone-200 gap-2"
      >
        <Share2 className="w-4 h-4" />
        Share
      </Button>

      {open && (
        <>
          {/* Backdrop */}
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />

          {/* Dropdown */}
          <div className="absolute right-0 top-10 z-50 w-72 bg-white rounded-2xl shadow-xl border border-stone-200 p-4">
            <div className="flex items-center justify-between mb-3">
              <p className="font-semibold text-stone-800 text-sm">Share this recipe</p>
              <button onClick={() => setOpen(false)} className="text-stone-400 hover:text-stone-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Preview card */}
            <div className="rounded-xl border border-stone-200 overflow-hidden mb-4">
              {shareImage ? (
                <img src={shareImage} alt={shareTitle} className="w-full h-28 object-cover" />
              ) : (
                <div className="w-full h-28 bg-gradient-to-br from-emerald-100 to-amber-100 flex items-center justify-center">
                  <span className="text-3xl">🌿</span>
                </div>
              )}
              <div className="p-3 bg-stone-50">
                <p className="text-xs text-stone-400 mb-0.5">earthgoods.app</p>
                <p className="text-sm font-semibold text-stone-800 line-clamp-1">{shareTitle}</p>
                {recipe.description && (
                  <p className="text-xs text-stone-500 mt-0.5 line-clamp-2">{recipe.description}</p>
                )}
              </div>
            </div>

            {/* Copy link */}
            <div className="flex gap-2 mb-4">
              <div className="flex-1 bg-stone-100 rounded-lg px-3 py-2 text-xs text-stone-500 truncate">
                {shareUrl}
              </div>
              <Button
                size="sm"
                onClick={handleCopy}
                className={`flex-shrink-0 rounded-lg h-9 px-3 transition-colors ${
                  copied ? 'bg-emerald-600 hover:bg-emerald-600 text-white' : 'bg-stone-800 hover:bg-stone-700 text-white'
                }`}
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span className="ml-1 text-xs">{copied ? 'Copied!' : 'Copy'}</span>
              </Button>
            </div>

            {/* Platform buttons */}
            <div className="grid grid-cols-2 gap-2">
              {platforms.map(platform => (
                <button
                  key={platform.name}
                  onClick={() => handleShare(platform)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium transition-opacity hover:opacity-90 ${platform.color}`}
                >
                  {platform.icon
                    ? <platform.icon className="w-4 h-4" />
                    : platform.svg}
                  {platform.name}
                </button>
              ))}
            </div>

            {canNativeShare && (
              <button
                onClick={handleNativeShare}
                className="mt-2 w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-medium bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors"
              >
                <Share2 className="w-3.5 h-3.5" />
                More options…
              </button>
            )}
          </div>
        </>
      )}
    </div>
  );
}