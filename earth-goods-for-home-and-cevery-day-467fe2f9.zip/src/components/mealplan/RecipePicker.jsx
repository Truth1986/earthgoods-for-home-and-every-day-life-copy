import React, { useState } from 'react';
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, ChefHat, Check } from "lucide-react";

const categoryColors = {
  homesteading: "bg-amber-100 text-amber-800", baking: "bg-orange-100 text-orange-800",
  preserving: "bg-lime-100 text-lime-800", fermentation: "bg-yellow-100 text-yellow-800",
  gardening: "bg-emerald-100 text-emerald-800", animal_care: "bg-rose-100 text-rose-800",
  herbal: "bg-teal-100 text-teal-800", seasonal: "bg-stone-100 text-stone-800",
};

const categoryLabels = {
  homesteading: "Homesteading", baking: "Baking", preserving: "Preserving",
  fermentation: "Fermentation", gardening: "Gardening", animal_care: "Animal Care",
  herbal: "Herbal", seasonal: "Seasonal",
};

export default function RecipePicker({ recipes, selectedIds, onToggle }) {
  const [search, setSearch] = useState('');

  const filtered = recipes.filter(r =>
    !search || r.title?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
        <Input
          placeholder="Search recipes..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="pl-9 h-10 rounded-full border-stone-200"
        />
      </div>
      <div className="grid sm:grid-cols-2 gap-3 max-h-96 overflow-y-auto pr-1">
        {filtered.map(recipe => {
          const selected = selectedIds.includes(recipe.id);
          return (
            <button
              key={recipe.id}
              onClick={() => onToggle(recipe.id)}
              className={`text-left rounded-xl border-2 p-3 transition-all flex items-start gap-3 ${
                selected
                  ? 'border-emerald-500 bg-emerald-50'
                  : 'border-stone-200 bg-white hover:border-emerald-300'
              }`}
            >
              <div className={`w-5 h-5 rounded-full border-2 flex-shrink-0 mt-0.5 flex items-center justify-center transition-colors ${
                selected ? 'bg-emerald-600 border-emerald-600' : 'border-stone-300'
              }`}>
                {selected && <Check className="w-3 h-3 text-white" />}
              </div>
              <div className="min-w-0">
                {recipe.cover_image_url ? (
                  <img src={recipe.cover_image_url} alt={recipe.title} className="w-full h-20 object-cover rounded-lg mb-2" />
                ) : (
                  <div className="w-full h-20 rounded-lg bg-gradient-to-br from-emerald-100 to-amber-100 flex items-center justify-center mb-2">
                    <ChefHat className="w-8 h-8 text-emerald-400" />
                  </div>
                )}
                <p className="font-medium text-stone-800 text-sm leading-snug line-clamp-2">{recipe.title}</p>
                {recipe.category && (
                  <Badge className={`${categoryColors[recipe.category]} border-0 text-xs mt-1`}>
                    {categoryLabels[recipe.category]}
                  </Badge>
                )}
                <p className="text-xs text-stone-400 mt-1">{recipe.ingredients?.length || 0} ingredients</p>
              </div>
            </button>
          );
        })}
        {filtered.length === 0 && (
          <div className="col-span-2 text-center py-8 text-stone-400">
            <ChefHat className="w-10 h-10 mx-auto mb-2 text-stone-300" />
            No recipes found
          </div>
        )}
      </div>
    </div>
  );
}