import React, { useMemo } from 'react';
import { ShoppingCart, RotateCcw, Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function ShoppingList({ recipes, selectedIds, checkedKeys, onToggleCheck, onClearChecked }) {
  const selectedRecipes = recipes.filter(r => selectedIds.includes(r.id));

  // Aggregate all ingredients keyed by "recipeId|index"
  const groupedByRecipe = useMemo(() => {
    return selectedRecipes.map(recipe => ({
      recipe,
      ingredients: (recipe.ingredients || []).map((ing, idx) => ({
        key: `${recipe.id}|${idx}`,
        text: ing.text,
      })),
    }));
  }, [selectedRecipes]);

  const allIngredients = groupedByRecipe.flatMap(g => g.ingredients);
  const checkedCount = allIngredients.filter(i => checkedKeys.includes(i.key)).length;

  if (selectedIds.length === 0) {
    return (
      <div className="text-center py-16 bg-stone-50 rounded-2xl border-2 border-dashed border-stone-200">
        <ShoppingCart className="w-12 h-12 mx-auto text-stone-300 mb-3" />
        <p className="text-stone-500 font-medium">Select recipes to build your shopping list</p>
        <p className="text-stone-400 text-sm mt-1">Ingredients will be grouped by recipe</p>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <h3 className="font-semibold text-stone-800">Shopping List</h3>
          <Badge className="bg-emerald-100 text-emerald-800 border-0">
            {checkedCount}/{allIngredients.length} checked
          </Badge>
        </div>
        <div className="flex gap-2">
          {checkedCount > 0 && (
            <Button variant="ghost" size="sm" onClick={onClearChecked} className="text-stone-500 h-8">
              <RotateCcw className="w-3 h-3 mr-1" />
              Reset
            </Button>
          )}
          <Button variant="ghost" size="sm" onClick={() => window.print()} className="text-stone-500 h-8">
            <Printer className="w-3 h-3 mr-1" />
            Print
          </Button>
        </div>
      </div>

      {/* Progress bar */}
      <div className="w-full bg-stone-100 rounded-full h-2 mb-6">
        <div
          className="bg-emerald-500 h-2 rounded-full transition-all duration-300"
          style={{ width: allIngredients.length ? `${(checkedCount / allIngredients.length) * 100}%` : '0%' }}
        />
      </div>

      {/* Ingredients grouped by recipe */}
      <div className="space-y-6">
        {groupedByRecipe.map(({ recipe, ingredients }) => (
          <div key={recipe.id}>
            <p className="text-sm font-semibold text-emerald-700 uppercase tracking-wide mb-2 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
              {recipe.title}
            </p>
            <ul className="space-y-2">
              {ingredients.map(({ key, text }) => {
                const checked = checkedKeys.includes(key);
                return (
                  <li key={key}>
                    <label className="flex items-center gap-3 cursor-pointer group">
                      <div
                        onClick={() => onToggleCheck(key)}
                        className={`w-5 h-5 rounded border-2 flex-shrink-0 flex items-center justify-center transition-colors ${
                          checked
                            ? 'bg-emerald-600 border-emerald-600'
                            : 'border-stone-300 group-hover:border-emerald-400'
                        }`}
                      >
                        {checked && (
                          <svg className="w-3 h-3 text-white" viewBox="0 0 12 12" fill="none">
                            <path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                          </svg>
                        )}
                      </div>
                      <span
                        onClick={() => onToggleCheck(key)}
                        className={`text-sm transition-colors ${checked ? 'line-through text-stone-400' : 'text-stone-700'}`}
                      >
                        {text}
                      </span>
                    </label>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>

      {checkedCount === allIngredients.length && allIngredients.length > 0 && (
        <div className="mt-6 p-4 bg-emerald-50 rounded-xl text-center border border-emerald-200">
          <p className="text-emerald-700 font-semibold">🎉 All ingredients checked! Ready to cook.</p>
        </div>
      )}
    </div>
  );
}