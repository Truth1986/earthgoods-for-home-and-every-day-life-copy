import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    // Only admins can trigger inventory sync
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    console.log('Starting inventory sync from dropshipper API...');

    // STEP 1: Fetch inventory from your dropshipper API
    // Replace with your actual dropshipper API endpoint and auth
    const dropshipperResponse = await fetch('YOUR_DROPSHIPPER_API_ENDPOINT', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('DROPSHIPPER_API_KEY')}`,
        'Content-Type': 'application/json',
      },
    });

    if (!dropshipperResponse.ok) {
      throw new Error(`Dropshipper API error: ${dropshipperResponse.status}`);
    }

    const dropshipperData = await dropshipperResponse.json();
    console.log(`Fetched ${dropshipperData.products?.length || 0} products from dropshipper`);

    // STEP 2: Get all products from our database
    const allProducts = await base44.asServiceRole.entities.Product.list('-created_date', 1000);
    console.log(`Found ${allProducts.length} products in database`);

    // STEP 3: Create a map of supplier SKUs for quick lookup
    const skuMap = {};
    allProducts.forEach(product => {
      if (product.supplier_sku) {
        skuMap[product.supplier_sku] = product;
      }
    });

    // STEP 4: Update stock for each product
    let updatedCount = 0;
    let errorCount = 0;

    for (const dropshipperProduct of dropshipperData.products || []) {
      try {
        // Find matching product by supplier SKU
        const ourProduct = skuMap[dropshipperProduct.sku];
        
        if (!ourProduct) {
          console.log(`No match found for SKU: ${dropshipperProduct.sku}`);
          continue;
        }

        const newStock = dropshipperProduct.quantity || dropshipperProduct.stock || 0;
        
        // Only update if stock changed
        if (ourProduct.stock !== newStock) {
          await base44.asServiceRole.entities.Product.update(ourProduct.id, {
            stock: newStock,
          });
          updatedCount++;
          console.log(`✓ Updated ${ourProduct.title} stock: ${ourProduct.stock} → ${newStock}`);
        }
      } catch (error) {
        errorCount++;
        console.error(`Error updating product ${dropshipperProduct.sku}:`, error.message);
      }
    }

    const summary = {
      status: 'success',
      syncedAt: new Date().toISOString(),
      totalProducts: allProducts.length,
      updatedCount,
      errorCount,
      message: `Synced inventory. Updated ${updatedCount} products, ${errorCount} errors.`,
    };

    console.log('Inventory sync completed:', summary);
    return Response.json(summary);

  } catch (error) {
    console.error('Critical error in inventory sync:', error.message);
    return Response.json({
      status: 'error',
      error: error.message,
      syncedAt: new Date().toISOString(),
    }, { status: 500 });
  }
});