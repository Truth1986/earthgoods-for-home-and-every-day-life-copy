import Stripe from 'npm:stripe';
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      plan_id,
      plan_name,
      monthly_price,
      discount_percent,
      stripe_price_id,
      customer_email,
    } = await req.json();

    if (!stripe_price_id) {
      console.error('Missing Stripe price ID for plan:', plan_id);
      return Response.json(
        { error: 'Plan is not configured for subscription' },
        { status: 400 }
      );
    }

    // Create Stripe checkout session for recurring subscription
    const session = await stripe.checkout.sessions.create({
      customer_email: customer_email,
      mode: 'subscription',
      line_items: [
        {
          price: stripe_price_id,
          quantity: 1,
        },
      ],
      subscription_data: {
        description: `${plan_name} subscription`,
        metadata: {
          plan_id: plan_id,
          plan_name: plan_name,
          discount_percent: discount_percent.toString(),
        },
      },
      success_url: `${new URL(req.url).origin}/Subscriptions?success=true&plan=${plan_id}`,
      cancel_url: `${new URL(req.url).origin}/Subscriptions`,
      metadata: {
        base44_app_id: Deno.env.get('BASE44_APP_ID'),
        user_email: customer_email,
        plan_id: plan_id,
      },
    });

    console.log('Subscription checkout session created:', session.id);

    return Response.json({ url: session.url });
  } catch (error) {
    console.error('Subscription checkout error:', error.message);
    return Response.json(
      { error: 'Failed to create subscription checkout: ' + error.message },
      { status: 500 }
    );
  }
});