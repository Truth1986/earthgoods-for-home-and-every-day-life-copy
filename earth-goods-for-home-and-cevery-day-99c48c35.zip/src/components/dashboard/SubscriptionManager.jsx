import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, Pause, Play, Trash2, AlertCircle, Check } from "lucide-react";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function SubscriptionManager({ user }) {
  const queryClient = useQueryClient();
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [selectedSubId, setSelectedSubId] = useState(null);

  const { data: subscriptions = [], isLoading } = useQuery({
    queryKey: ['my-subscriptions', user?.email],
    queryFn: () => base44.entities.Subscription.filter(
      { customer_email: user.email },
      '-created_date'
    ),
    enabled: !!user?.email,
  });

  const pauseMutation = useMutation({
    mutationFn: (id) => base44.entities.Subscription.update(id, { status: 'paused' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my-subscriptions', user?.email] });
      toast.success('Subscription paused');
    },
  });

  const resumeMutation = useMutation({
    mutationFn: (id) => base44.entities.Subscription.update(id, { status: 'active' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my-subscriptions', user?.email] });
      toast.success('Subscription resumed');
    },
  });

  const cancelMutation = useMutation({
    mutationFn: (id) => base44.entities.Subscription.update(id, {
      status: 'cancelled',
      cancelled_date: new Date().toISOString().split('T')[0],
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my-subscriptions', user?.email] });
      setCancelDialogOpen(false);
      setSelectedSubId(null);
      toast.success('Subscription cancelled');
    },
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2].map(i => (
          <Card key={i} className="animate-pulse"><CardContent className="p-6 h-48" /></Card>
        ))}
      </div>
    );
  }

  if (subscriptions.length === 0) {
    return (
      <Card className="bg-white border-stone-200">
        <CardContent className="p-12 text-center">
          <Clock className="w-16 h-16 mx-auto text-stone-300 mb-4" />
          <h3 className="text-xl font-semibold text-stone-700 mb-2">No active subscriptions</h3>
          <p className="text-stone-500 mb-6">Start saving with a monthly subscription plan</p>
          <a href="/Subscriptions" className="inline-block">
            <Button className="bg-emerald-600 hover:bg-emerald-700 rounded-full">
              Browse Plans
            </Button>
          </a>
        </CardContent>
      </Card>
    );
  }

  const activeSubscriptions = subscriptions.filter(s => s.status === 'active');
  const pausedSubscriptions = subscriptions.filter(s => s.status === 'paused');
  const cancelledSubscriptions = subscriptions.filter(s => s.status === 'cancelled');

  const SubCard = ({ sub }) => (
    <Card className="bg-white border-stone-200">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg">{sub.plan_name}</CardTitle>
            <p className="text-sm text-stone-500 mt-1">
              Started {new Date(sub.created_date).toLocaleDateString()}
            </p>
          </div>
          <Badge className={`border-0 ${
            sub.status === 'active' ? 'bg-emerald-100 text-emerald-800' :
            sub.status === 'paused' ? 'bg-amber-100 text-amber-800' :
            'bg-stone-100 text-stone-800'
          }`}>
            {sub.status === 'active' ? '✓ Active' : 
             sub.status === 'paused' ? '⏸ Paused' : 
             '✗ Cancelled'}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Pricing */}
        <div className="grid sm:grid-cols-3 gap-4">
          <div>
            <p className="text-xs text-stone-500 uppercase tracking-wide">Monthly Cost</p>
            <p className="text-2xl font-bold text-stone-800">${sub.monthly_price.toFixed(2)}</p>
            {sub.discount_percent > 0 && (
              <p className="text-xs text-emerald-600 mt-1">Save {sub.discount_percent}%</p>
            )}
          </div>
          <div>
            <p className="text-xs text-stone-500 uppercase tracking-wide">Deliveries</p>
            <p className="text-2xl font-bold text-stone-800">{sub.billing_count}</p>
            <p className="text-xs text-stone-500 mt-1">Total: ${sub.total_billed.toFixed(2)}</p>
          </div>
          <div>
            <p className="text-xs text-stone-500 uppercase tracking-wide">Next Delivery</p>
            <p className="text-lg font-bold text-stone-800">{sub.next_billing_date}</p>
          </div>
        </div>

        {/* Actions */}
        {sub.status === 'active' && (
          <div className="flex gap-3 pt-2 border-t border-stone-100">
            <Button
              variant="outline"
              size="sm"
              className="flex-1 rounded-full"
              onClick={() => pauseMutation.mutate(sub.id)}
              disabled={pauseMutation.isPending}
            >
              <Pause className="w-4 h-4 mr-2" />
              Pause
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="flex-1 rounded-full text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
              onClick={() => {
                setSelectedSubId(sub.id);
                setCancelDialogOpen(true);
              }}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Cancel
            </Button>
          </div>
        )}

        {sub.status === 'paused' && (
          <div className="pt-2 border-t border-stone-100">
            <Button
              className="w-full bg-emerald-600 hover:bg-emerald-700 rounded-full"
              onClick={() => resumeMutation.mutate(sub.id)}
              disabled={resumeMutation.isPending}
            >
              <Play className="w-4 h-4 mr-2" />
              Resume Subscription
            </Button>
          </div>
        )}

        {sub.status === 'cancelled' && sub.cancelled_date && (
          <div className="bg-stone-50 rounded-lg p-3 text-sm text-stone-600">
            <p>Cancelled on {new Date(sub.cancelled_date).toLocaleDateString()}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-8">
      {/* Active Subscriptions */}
      {activeSubscriptions.length > 0 && (
        <div>
          <h2 className="text-xl font-bold text-stone-800 mb-4 flex items-center gap-2">
            <Check className="w-5 h-5 text-emerald-600" />
            Active Subscriptions
          </h2>
          <div className="space-y-4">
            {activeSubscriptions.map(sub => (
              <SubCard key={sub.id} sub={sub} />
            ))}
          </div>
        </div>
      )}

      {/* Paused Subscriptions */}
      {pausedSubscriptions.length > 0 && (
        <div>
          <h2 className="text-xl font-bold text-stone-800 mb-4">Paused Subscriptions</h2>
          <div className="space-y-4">
            {pausedSubscriptions.map(sub => (
              <SubCard key={sub.id} sub={sub} />
            ))}
          </div>
        </div>
      )}

      {/* Cancelled Subscriptions */}
      {cancelledSubscriptions.length > 0 && (
        <div>
          <h2 className="text-xl font-bold text-stone-800 mb-4">Cancelled Subscriptions</h2>
          <div className="space-y-4">
            {cancelledSubscriptions.map(sub => (
              <SubCard key={sub.id} sub={sub} />
            ))}
          </div>
        </div>
      )}

      {/* Cancel Confirmation Dialog */}
      <AlertDialog open={cancelDialogOpen} onOpenChange={setCancelDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-600" />
              Cancel Subscription?
            </AlertDialogTitle>
            <AlertDialogDescription>
              This will cancel your subscription. You can always restart it later. Your next scheduled delivery will not be processed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="flex gap-3">
            <AlertDialogCancel className="rounded-full">Keep Subscription</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700 rounded-full"
              onClick={() => cancelMutation.mutate(selectedSubId)}
              disabled={cancelMutation.isPending}
            >
              {cancelMutation.isPending ? 'Cancelling...' : 'Cancel Subscription'}
            </AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}