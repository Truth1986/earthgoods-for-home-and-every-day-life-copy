import React, { useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline } from 'react-leaflet';
import L from 'leaflet';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Truck } from "lucide-react";

// Mock warehouse and delivery locations
const WAREHOUSE = { lat: 41.8781, lng: -87.6298, name: 'Chicago Distribution Hub' };
const SAMPLE_DESTINATIONS = {
  'New York': { lat: 40.7128, lng: -74.0060 },
  'Los Angeles': { lat: 34.0522, lng: -118.2437 },
  'Texas': { lat: 31.9686, lng: -99.9018 },
  'Florida': { lat: 27.9947, lng: -81.7603 },
  'Seattle': { lat: 47.6062, lng: -122.3321 },
};

// Extract state from address or use default
function getDestinationFromAddress(address) {
  if (!address) return SAMPLE_DESTINATIONS['Texas'];
  
  const stateMatch = address.match(/,\s*([A-Z]{2})\s/);
  if (stateMatch) {
    const state = stateMatch[1];
    if (state === 'NY') return SAMPLE_DESTINATIONS['New York'];
    if (state === 'CA') return SAMPLE_DESTINATIONS['Los Angeles'];
    if (state === 'TX') return SAMPLE_DESTINATIONS['Texas'];
    if (state === 'FL') return SAMPLE_DESTINATIONS['Florida'];
    if (state === 'WA') return SAMPLE_DESTINATIONS['Seattle'];
  }
  
  return SAMPLE_DESTINATIONS['Texas'];
}

// Custom icon for warehouse
const warehouseIcon = new L.Icon({
  iconUrl: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23059669"><path d="M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z"/></svg>',
  iconSize: [32, 32],
  iconAnchor: [16, 32],
});

// Custom icon for delivery
const truckIcon = new L.Icon({
  iconUrl: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%235b21b6"><path d="M18 18.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0M1 6v9a2 2 0 0 0 2 2h1v3h3v-3h7v3h3v-3h1a2 2 0 0 0 2-2v-4h2V8h-2V6H1m8-1h8v3H9V5z"/></svg>',
  iconSize: [32, 32],
  iconAnchor: [16, 32],
});

// Custom icon for destination
const destinationIcon = new L.Icon({
  iconUrl: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23dc2626"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8m3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5z"/></svg>',
  iconSize: [32, 32],
  iconAnchor: [16, 32],
});

export default function OrderMapVisualization({ order }) {
  const destination = useMemo(() => 
    getDestinationFromAddress(order.customer_address),
    [order.customer_address]
  );

  // Calculate route path based on order status
  const routePath = useMemo(() => {
    if (order.status === 'pending' || order.status === 'paid') {
      return null; // No route yet
    }
    
    if (order.status === 'shipped') {
      // In transit - show partial route
      const progress = 0.5;
      return [
        [WAREHOUSE.lat, WAREHOUSE.lng],
        [
          WAREHOUSE.lat + (destination.lat - WAREHOUSE.lat) * progress,
          WAREHOUSE.lng + (destination.lng - WAREHOUSE.lng) * progress,
        ],
      ];
    }
    
    // Delivered - show full route
    return [
      [WAREHOUSE.lat, WAREHOUSE.lng],
      [destination.lat, destination.lng],
    ];
  }, [order.status, destination]);

  return (
    <Card className="bg-white border-stone-200 overflow-hidden">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="w-5 h-5 text-emerald-600" />
          Package Location
        </CardTitle>
      </CardHeader>
      <CardContent>
        {order.status === 'pending' || order.status === 'paid' ? (
          <div className="h-96 bg-stone-50 rounded-lg flex items-center justify-center text-center">
            <div>
              <Truck className="w-12 h-12 mx-auto text-stone-300 mb-3" />
              <p className="text-stone-600 font-medium">Map available once shipped</p>
              <p className="text-sm text-stone-500 mt-1">Your order is being prepared</p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <MapContainer
              center={[
                (WAREHOUSE.lat + destination.lat) / 2,
                (WAREHOUSE.lng + destination.lng) / 2,
              ]}
              zoom={5}
              style={{ height: '400px', borderRadius: '8px' }}
              scrollWheelZoom={false}
            >
              <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; OpenStreetMap contributors'
              />

              {/* Warehouse marker */}
              <Marker position={[WAREHOUSE.lat, WAREHOUSE.lng]} icon={warehouseIcon}>
                <Popup>
                  <div className="text-sm">
                    <p className="font-semibold">{WAREHOUSE.name}</p>
                    <p className="text-xs text-stone-500">Distribution Hub</p>
                  </div>
                </Popup>
              </Marker>

              {/* Route */}
              {routePath && (
                <Polyline
                  positions={routePath}
                  color={order.status === 'delivered' ? '#059669' : '#9333ea'}
                  weight={3}
                  opacity={0.7}
                />
              )}

              {/* Delivery destination */}
              <Marker position={[destination.lat, destination.lng]} icon={destinationIcon}>
                <Popup>
                  <div className="text-sm">
                    <p className="font-semibold">Delivery Address</p>
                    <p className="text-xs text-stone-500 mt-1">{order.customer_address}</p>
                  </div>
                </Popup>
              </Marker>

              {/* Current location (in transit only) */}
              {order.status === 'shipped' && (
                <Marker
                  position={[
                    WAREHOUSE.lat + (destination.lat - WAREHOUSE.lat) * 0.5,
                    WAREHOUSE.lng + (destination.lng - WAREHOUSE.lng) * 0.5,
                  ]}
                  icon={truckIcon}
                >
                  <Popup>
                    <div className="text-sm">
                      <p className="font-semibold">In Transit</p>
                      <p className="text-xs text-stone-500 mt-1">Estimated 2-3 days delivery</p>
                    </div>
                  </Popup>
                </Marker>
              )}
            </MapContainer>

            {/* Status info */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="bg-stone-50 rounded-lg p-4">
                <p className="text-xs text-stone-500 uppercase tracking-wide mb-1">From</p>
                <p className="font-semibold text-stone-800">{WAREHOUSE.name}</p>
                <p className="text-sm text-stone-600">Chicago, IL</p>
              </div>
              <div className="bg-stone-50 rounded-lg p-4">
                <p className="text-xs text-stone-500 uppercase tracking-wide mb-1">To</p>
                <p className="font-semibold text-stone-800">Your Address</p>
                <p className="text-sm text-stone-600 truncate">{order.customer_address}</p>
              </div>
            </div>

            {/* Status badge */}
            <div className="flex items-center gap-2">
              <span className="text-sm text-stone-600">Current Status:</span>
              <Badge className={`${
                order.status === 'shipped' ? 'bg-purple-100 text-purple-800' :
                order.status === 'delivered' ? 'bg-green-100 text-green-800' :
                'bg-stone-100 text-stone-800'
              } border-0`}>
                {order.status === 'shipped' && '🚚 In Transit'}
                {order.status === 'delivered' && '✓ Delivered'}
              </Badge>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}