import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import NavigationTracker from '@/lib/NavigationTracker'
import { pagesConfig } from './pages.config'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import CustomerDashboard from './pages/CustomerDashboard';
import Blog from './pages/Blog';
import BlogPost from './pages/BlogPost';
import BlogEditor from './pages/BlogEditor';
import MarketingHub from './pages/MarketingHub';
import Recipes from './pages/Recipes';
import RecipeDetail from './pages/RecipeDetail';
import TrackOrder from './pages/TrackOrder';
import DropshippingDashboard from './pages/DropshippingDashboard';
import NewsletterCampaigns from './pages/NewsletterCampaigns';
import NewsletterAnalytics from './pages/NewsletterAnalytics';
import Subscriptions from './pages/Subscriptions';
import RecipeEditor from './pages/RecipeEditor';
import MyOrders from './pages/MyOrders';

const { Pages, Layout, mainPage } = pagesConfig;
const mainPageKey = mainPage ?? Object.keys(Pages)[0];
const MainPage = mainPageKey ? Pages[mainPageKey] : <></>;

const LayoutWrapper = ({ children, currentPageName }) => Layout ?
  <Layout currentPageName={currentPageName}>{children}</Layout>
  : <>{children}</>;

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/" element={
        <LayoutWrapper currentPageName={mainPageKey}>
          <MainPage />
        </LayoutWrapper>
      } />
      {Object.entries(Pages).map(([path, Page]) => (
        <Route
          key={path}
          path={`/${path}`}
          element={
            <LayoutWrapper currentPageName={path}>
              <Page />
            </LayoutWrapper>
          }
        />
      ))}
      <Route path="/CustomerDashboard" element={<CustomerDashboard />} />
      <Route path="/Blog" element={<Blog />} />
      <Route path="/BlogPost" element={<BlogPost />} />
      <Route path="/BlogEditor" element={<BlogEditor />} />
      <Route path="/MarketingHub" element={<MarketingHub />} />
      <Route path="/Recipes" element={<Recipes />} />
      <Route path="/RecipeDetail" element={<RecipeDetail />} />
      <Route path="/TrackOrder" element={<TrackOrder />} />
      <Route path="/DropshippingDashboard" element={<DropshippingDashboard />} />
      <Route path="/NewsletterCampaigns" element={<NewsletterCampaigns />} />
      <Route path="/NewsletterAnalytics" element={<NewsletterAnalytics />} />
      <Route path="/Subscriptions" element={<Subscriptions />} />
      <Route path="/RecipeEditor" element={<RecipeEditor />} />
      <Route path="/RecipeDetail" element={<RecipeDetail />} />
      <Route path="/MyOrders" element={<MyOrders />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <NavigationTracker />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App