import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Leaf, Plus, Trash2, Save, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const categories = ["homesteading", "baking", "preserving", "fermentation", "gardening", "animal_care", "herbal", "seasonal"];
const difficulties = ["easy", "medium", "hard"];

export default function RecipeEditor() {
  const queryClient = useQueryClient();
  const [recipes, setRecipes] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    slug: '',
    description: '',
    cover_image_url: '',
    category: 'homesteading',
    prep_time_minutes: 0,
    cook_time_minutes: 0,
    servings: 1,
    difficulty: 'easy',
    ingredients: [],
    instructions: [],
    tips: '',
    status: 'draft',
    author_name: '',
    tags: []
  });

  const { data: allRecipes = [], isLoading } = useQuery({
    queryKey: ['recipes'],
    queryFn: () => base44.entities.Recipe.list('-created_date'),
  });

  useEffect(() => {
    setRecipes(allRecipes);
  }, [allRecipes]);

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Recipe.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recipes'] });
      resetForm();
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Recipe.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recipes'] });
      resetForm();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Recipe.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['recipes'] }),
  });

  const resetForm = () => {
    setFormData({
      title: '',
      slug: '',
      description: '',
      cover_image_url: '',
      category: 'homesteading',
      prep_time_minutes: 0,
      cook_time_minutes: 0,
      servings: 1,
      difficulty: 'easy',
      ingredients: [],
      instructions: [],
      tips: '',
      status: 'draft',
      author_name: '',
      tags: []
    });
    setEditingId(null);
  };

  const handleEdit = (recipe) => {
    setFormData(recipe);
    setEditingId(recipe.id);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const dataToSubmit = {
      ...formData,
      slug: formData.slug || formData.title.toLowerCase().replace(/\s+/g, '-'),
    };

    if (editingId) {
      updateMutation.mutate({ id: editingId, data: dataToSubmit });
    } else {
      createMutation.mutate(dataToSubmit);
    }
  };

  const addIngredient = () => {
    setFormData({
      ...formData,
      ingredients: [...formData.ingredients, { text: '', product_id: '' }]
    });
  };

  const updateIngredient = (idx, field, value) => {
    const newIngredients = [...formData.ingredients];
    newIngredients[idx][field] = value;
    setFormData({ ...formData, ingredients: newIngredients });
  };

  const removeIngredient = (idx) => {
    setFormData({
      ...formData,
      ingredients: formData.ingredients.filter((_, i) => i !== idx)
    });
  };

  const addInstruction = () => {
    const nextStep = (formData.instructions.length || 0) + 1;
    setFormData({
      ...formData,
      instructions: [...formData.instructions, { step: nextStep, text: '' }]
    });
  };

  const updateInstruction = (idx, value) => {
    const newInstructions = [...formData.instructions];
    newInstructions[idx].text = value;
    setFormData({ ...formData, instructions: newInstructions });
  };

  const removeInstruction = (idx) => {
    setFormData({
      ...formData,
      instructions: formData.instructions.filter((_, i) => i !== idx).map((inst, i) => ({ ...inst, step: i + 1 }))
    });
  };

  return (
    <div className="min-h-screen bg-stone-50">
      <header className="bg-white border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to={createPageUrl('Home')} className="flex items-center gap-2">
            <Leaf className="w-5 h-5 text-emerald-600" />
            <span className="font-bold text-stone-800">EarthGoods Admin</span>
          </Link>
          <Link to={createPageUrl('AdminDashboard')}>
            <Button variant="outline" className="rounded-full">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </Link>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Form */}
          <div className="md:col-span-2">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>{editingId ? 'Edit Recipe' : 'Create New Recipe'}</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Title *</label>
                      <Input
                        value={formData.title}
                        onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                        placeholder="Recipe title"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Author Name</label>
                      <Input
                        value={formData.author_name}
                        onChange={(e) => setFormData({ ...formData, author_name: e.target.value })}
                        placeholder="Your name"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Description</label>
                    <Textarea
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      placeholder="Short description"
                      rows={2}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Cover Image URL</label>
                    <Input
                      value={formData.cover_image_url}
                      onChange={(e) => setFormData({ ...formData, cover_image_url: e.target.value })}
                      placeholder="https://..."
                    />
                  </div>

                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Category</label>
                      <select
                        value={formData.category}
                        onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                        className="w-full px-3 py-2 border border-stone-200 rounded-lg text-sm"
                      >
                        {categories.map(cat => (
                          <option key={cat} value={cat}>{cat}</option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Difficulty</label>
                      <select
                        value={formData.difficulty}
                        onChange={(e) => setFormData({ ...formData, difficulty: e.target.value })}
                        className="w-full px-3 py-2 border border-stone-200 rounded-lg text-sm"
                      >
                        {difficulties.map(diff => (
                          <option key={diff} value={diff}>{diff}</option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Status</label>
                      <select
                        value={formData.status}
                        onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                        className="w-full px-3 py-2 border border-stone-200 rounded-lg text-sm"
                      >
                        <option value="draft">Draft</option>
                        <option value="published">Published</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Prep Time (min)</label>
                      <Input
                        type="number"
                        value={formData.prep_time_minutes}
                        onChange={(e) => setFormData({ ...formData, prep_time_minutes: parseInt(e.target.value) || 0 })}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Cook Time (min)</label>
                      <Input
                        type="number"
                        value={formData.cook_time_minutes}
                        onChange={(e) => setFormData({ ...formData, cook_time_minutes: parseInt(e.target.value) || 0 })}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Servings</label>
                      <Input
                        type="number"
                        value={formData.servings}
                        onChange={(e) => setFormData({ ...formData, servings: parseInt(e.target.value) || 1 })}
                      />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium">Ingredients *</label>
                      <Button type="button" size="sm" variant="outline" onClick={addIngredient}>
                        <Plus className="w-3 h-3 mr-1" /> Add
                      </Button>
                    </div>
                    <div className="space-y-2">
                      {formData.ingredients.map((ing, idx) => (
                        <div key={idx} className="flex gap-2">
                          <Input
                            value={ing.text}
                            onChange={(e) => updateIngredient(idx, 'text', e.target.value)}
                            placeholder="e.g. 2 cups flour"
                            className="flex-1"
                          />
                          <Button type="button" size="icon" variant="ghost" onClick={() => removeIngredient(idx)}>
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium">Instructions *</label>
                      <Button type="button" size="sm" variant="outline" onClick={addInstruction}>
                        <Plus className="w-3 h-3 mr-1" /> Add Step
                      </Button>
                    </div>
                    <div className="space-y-2">
                      {formData.instructions.map((inst, idx) => (
                        <div key={idx} className="flex gap-2">
                          <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center text-sm font-medium flex-shrink-0">
                            {inst.step}
                          </div>
                          <Textarea
                            value={inst.text}
                            onChange={(e) => updateInstruction(idx, e.target.value)}
                            placeholder="Step description"
                            className="flex-1"
                            rows={2}
                          />
                          <Button type="button" size="icon" variant="ghost" onClick={() => removeInstruction(idx)}>
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Tips & Notes</label>
                    <Textarea
                      value={formData.tips}
                      onChange={(e) => setFormData({ ...formData, tips: e.target.value })}
                      placeholder="Extra tips..."
                      rows={3}
                    />
                  </div>

                  <div className="flex gap-3">
                    <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700 rounded-full flex-1">
                      <Save className="w-4 h-4 mr-2" />
                      {editingId ? 'Update Recipe' : 'Create Recipe'}
                    </Button>
                    {editingId && (
                      <Button type="button" variant="outline" onClick={resetForm} className="rounded-full">
                        Cancel
                      </Button>
                    )}
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Recipe List */}
          <div>
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Recipes ({recipes.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {isLoading ? (
                    <p className="text-sm text-stone-500">Loading...</p>
                  ) : recipes.length === 0 ? (
                    <p className="text-sm text-stone-500">No recipes yet</p>
                  ) : (
                    recipes.map(recipe => (
                      <div key={recipe.id} className="p-3 rounded-lg bg-stone-50 border border-stone-200 group hover:bg-stone-100 transition">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1">
                            <p className="text-sm font-medium text-stone-800">{recipe.title}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge className={`text-xs ${recipe.status === 'published' ? 'bg-emerald-100 text-emerald-700' : 'bg-yellow-100 text-yellow-700'} border-0`}>
                                {recipe.status}
                              </Badge>
                              <span className="text-xs text-stone-500">{recipe.category}</span>
                            </div>
                          </div>
                          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition">
                            <Button size="icon" variant="ghost" onClick={() => handleEdit(recipe)} className="h-8 w-8">
                              ✎
                            </Button>
                            <Button size="icon" variant="ghost" onClick={() => deleteMutation.mutate(recipe.id)} className="h-8 w-8">
                              <Trash2 className="w-3 h-3 text-red-500" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}