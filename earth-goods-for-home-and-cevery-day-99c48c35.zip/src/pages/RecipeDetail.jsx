import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Leaf, Clock, Users, ChefHat, AlertCircle, ArrowLeft, ShoppingCart } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

const categoryLabels = {
  homesteading: "Homesteading",
  baking: "Baking",
  preserving: "Preserving",
  fermentation: "Fermentation",
  gardening: "Gardening",
  animal_care: "Animal Care",
  herbal: "Herbal",
  seasonal: "Seasonal"
};

const difficultyColors = {
  easy: "bg-green-100 text-green-800",
  medium: "bg-yellow-100 text-yellow-800",
  hard: "bg-red-100 text-red-800"
};

export default function RecipeDetail() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const slug = urlParams.get('slug');

  const { data: recipe, isLoading } = useQuery({
    queryKey: ['recipe', slug],
    queryFn: () => base44.entities.Recipe.filter({ slug }),
    select: (data) => data[0] || null,
    enabled: !!slug,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-emerald-600 border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!recipe) {
    return (
      <div className="min-h-screen bg-stone-50">
        <header className="bg-white border-b border-stone-200">
          <div className="max-w-4xl mx-auto px-4 py-4">
            <Link to={createPageUrl('Recipes')} className="flex items-center gap-2 text-emerald-600 hover:text-emerald-700">
              <ArrowLeft className="w-4 h-4" />
              Back to Recipes
            </Link>
          </div>
        </header>
        <div className="max-w-4xl mx-auto px-4 py-20 text-center">
          <AlertCircle className="w-16 h-16 mx-auto text-stone-300 mb-4" />
          <p className="text-stone-600">Recipe not found</p>
        </div>
      </div>
    );
  }

  const totalTime = (recipe.prep_time_minutes || 0) + (recipe.cook_time_minutes || 0);

  return (
    <div className="min-h-screen bg-stone-50">
      {/* Header */}
      <header className="bg-white border-b border-stone-200">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <Link to={createPageUrl('Recipes')} className="flex items-center gap-2 text-emerald-600 hover:text-emerald-700 font-medium">
            <ArrowLeft className="w-4 h-4" />
            Back to Recipes
          </Link>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Hero */}
        {recipe.cover_image_url && (
          <div className="rounded-2xl overflow-hidden shadow-lg mb-8 h-96">
            <img src={recipe.cover_image_url} alt={recipe.title} className="w-full h-full object-cover" />
          </div>
        )}

        {/* Title & Meta */}
        <div className="mb-8">
          <div className="flex flex-wrap items-center gap-3 mb-4">
            <Badge className="bg-emerald-100 text-emerald-800 border-0">{categoryLabels[recipe.category]}</Badge>
            <Badge className={`border-0 ${difficultyColors[recipe.difficulty]}`}>{recipe.difficulty}</Badge>
          </div>
          <h1 className="text-4xl font-bold text-stone-800 mb-2">{recipe.title}</h1>
          {recipe.author_name && (
            <p className="text-stone-600">By <span className="font-medium">{recipe.author_name}</span></p>
          )}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {recipe.prep_time_minutes > 0 && (
            <Card>
              <CardContent className="pt-6 text-center">
                <Clock className="w-5 h-5 text-amber-600 mx-auto mb-2" />
                <p className="text-sm text-stone-600">Prep</p>
                <p className="text-lg font-semibold text-stone-800">{recipe.prep_time_minutes}m</p>
              </CardContent>
            </Card>
          )}
          {recipe.cook_time_minutes > 0 && (
            <Card>
              <CardContent className="pt-6 text-center">
                <ChefHat className="w-5 h-5 text-emerald-600 mx-auto mb-2" />
                <p className="text-sm text-stone-600">Cook</p>
                <p className="text-lg font-semibold text-stone-800">{recipe.cook_time_minutes}m</p>
              </CardContent>
            </Card>
          )}
          {totalTime > 0 && (
            <Card>
              <CardContent className="pt-6 text-center">
                <Clock className="w-5 h-5 text-blue-600 mx-auto mb-2" />
                <p className="text-sm text-stone-600">Total</p>
                <p className="text-lg font-semibold text-stone-800">{totalTime}m</p>
              </CardContent>
            </Card>
          )}
          {recipe.servings && (
            <Card>
              <CardContent className="pt-6 text-center">
                <Users className="w-5 h-5 text-rose-600 mx-auto mb-2" />
                <p className="text-sm text-stone-600">Servings</p>
                <p className="text-lg font-semibold text-stone-800">{recipe.servings}</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Description */}
        {recipe.description && (
          <p className="text-lg text-stone-700 mb-8 leading-relaxed">{recipe.description}</p>
        )}

        <div className="grid md:grid-cols-3 gap-8">
          {/* Ingredients */}
          <div className="md:col-span-1">
            <Card className="border-0 shadow-lg">
              <CardContent className="pt-6">
                <h2 className="text-xl font-bold text-stone-800 mb-4 flex items-center gap-2">
                  <Leaf className="w-5 h-5 text-emerald-600" />
                  Ingredients
                </h2>
                <ul className="space-y-3">
                  {recipe.ingredients?.map((ing, idx) => (
                    <li key={idx} className="flex gap-3">
                      <span className="text-emerald-600 font-bold">•</span>
                      <span className="text-stone-700">{ing.text}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Instructions & Tips */}
          <div className="md:col-span-2 space-y-8">
            <Card className="border-0 shadow-lg">
              <CardContent className="pt-6">
                <h2 className="text-xl font-bold text-stone-800 mb-6">Instructions</h2>
                <div className="space-y-4">
                  {recipe.instructions?.map((inst, idx) => (
                    <div key={idx} className="flex gap-4">
                      <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-sm flex-shrink-0">
                        {inst.step}
                      </div>
                      <p className="text-stone-700 leading-relaxed pt-1">{inst.text}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {recipe.tips && (
              <Card className="border-0 shadow-lg bg-amber-50">
                <CardContent className="pt-6">
                  <h2 className="text-lg font-bold text-stone-800 mb-3 flex items-center gap-2">
                    <AlertCircle className="w-5 h-5 text-amber-600" />
                    Tips & Notes
                  </h2>
                  <p className="text-stone-700 leading-relaxed">{recipe.tips}</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Tags */}
        {recipe.tags?.length > 0 && (
          <div className="mt-8 pt-8 border-t border-stone-200">
            <p className="text-sm text-stone-600 mb-3">Tags:</p>
            <div className="flex flex-wrap gap-2">
              {recipe.tags.map(tag => (
                <Badge key={tag} variant="outline">{tag}</Badge>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}