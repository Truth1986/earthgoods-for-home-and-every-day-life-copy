import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Leaf, ArrowLeft, Check, ShoppingBag, Loader2, Truck, Zap, Tag, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";

export default function Checkout() {
  const [cart, setCart] = useState(() => {
    const saved = localStorage.getItem('cart');
    return saved ? JSON.parse(saved) : [];
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [form, setForm] = useState({
    customer_name: '',
    customer_email: '',
    customer_address: '',
    notes: ''
  });
  const [shipping, setShipping] = useState('standard');
  const [orderTotal, setOrderTotal] = useState(0);
  const [refInput, setRefInput] = useState('');
  const [appliedCode, setAppliedCode] = useState(null);
  const [refLoading, setRefLoading] = useState(false);
  const [refError, setRefError] = useState('');

  // Auto-apply ref from URL on load
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const ref = urlParams.get('ref');
    if (ref) {
      setRefInput(ref);
      applyCode(ref);
    }
  }, []);

  const applyCode = async (codeToApply) => {
    const code = (codeToApply || refInput).trim().toUpperCase();
    if (!code) return;
    setRefLoading(true);
    setRefError('');

    // Check referral codes first
    const referralResults = await base44.entities.ReferralCode.filter({ code, is_active: true });
    if (referralResults.length > 0) {
      setAppliedCode({ ...referralResults[0], _type: 'referral' });
      setRefLoading(false);
      return;
    }

    // Check discount codes
    const discountResults = await base44.entities.DiscountCode.filter({ code, is_active: true });
    if (discountResults.length > 0) {
      const dc = discountResults[0];
      const now = new Date();
      if (dc.expires_at && new Date(dc.expires_at) < now) {
        setRefError('This discount code has expired.');
      } else if (dc.max_uses && dc.uses_count >= dc.max_uses) {
        setRefError('This discount code has reached its usage limit.');
      } else {
        setAppliedCode({ ...dc, _type: 'discount', discount_percent: dc.discount_type === 'percent' ? dc.discount_value : null, discount_fixed: dc.discount_type === 'fixed' ? dc.discount_value : null });
      }
    } else {
      setRefError('Invalid or expired code.');
    }
    setRefLoading(false);
  };

  const removeCode = () => {
    setAppliedCode(null);
    setRefInput('');
    setRefError('');
  };

  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const discountAmount = appliedCode
    ? appliedCode._type === 'discount' && appliedCode.discount_fixed
      ? Math.min(appliedCode.discount_fixed, total)
      : total * ((appliedCode.discount_percent || 0) / 100)
    : 0;
  const discountedTotal = total - discountAmount;
  const fee = discountedTotal * 0.03;
  const shippingCost = shipping === 'overnight' ? discountedTotal * 0.20 : 0;
  const grandTotal = discountedTotal + fee + shippingCost;

  // Check if running in iframe (checkout won't work there)
  const isInIframe = window.self !== window.top;

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (isInIframe) {
      alert('Stripe checkout only works from the published app. Please open the app in a new tab.');
      return;
    }
    
    if (!form.customer_name || !form.customer_email || !form.customer_address) {
      toast.error('Please fill in all required fields');
      return;
    }

    setLoading(true);

    // Save order to DB first
    const orderData = {
      ...form,
      items: cart.map(item => ({
        product_id: item.id,
        title: item.title,
        price: item.price,
        quantity: item.quantity
      })),
      total: grandTotal,
      status: 'pending',
      notes: `${form.notes ? form.notes + '\n' : ''}Shipping: ${shipping === 'overnight' ? 'Overnight (+20%)' : 'Standard'}${appliedCode ? `\nReferral code: ${appliedCode.code}` : ''}`
    };

    const order = await base44.entities.Order.create(orderData);

    // Decrement inventory
    await Promise.all(
      cart.map(async (item) => {
        const products = await base44.entities.Product.filter({ id: item.id });
        if (products.length > 0) {
          const product = products[0];
          const newStock = Math.max(0, (product.stock || 0) - item.quantity);
          await base44.entities.Product.update(product.id, { stock: newStock });
        }
      })
    );

    // Handle referral rewards
    if (appliedCode) {
      await base44.entities.ReferralCode.update(appliedCode.id, {
        uses_count: (appliedCode.uses_count || 0) + 1
      });
      await base44.entities.ReferralReward.create({
        referrer_email: appliedCode.referrer_email,
        referred_email: form.customer_email,
        referral_code: appliedCode.code,
        discount_amount: parseFloat((total * 0.10).toFixed(2)),
        order_id: order.id,
        status: 'pending',
      });
    }

    // Create Stripe checkout session and redirect
    const response = await base44.functions.invoke('createCheckoutSession', {
      items: cart.map(item => ({
        product_id: item.id,
        title: item.title,
        price: item.price,
        quantity: item.quantity,
        image_url: item.image_url || null,
      })),
      customer_email: form.customer_email,
      shipping,
      appliedCode: appliedCode?.code || null,
      discountPercent: appliedCode?.discount_percent || 0,
      successUrl: `${window.location.origin}/Checkout?success=true&order=${order.id}`,
      cancelUrl: `${window.location.origin}/Checkout`,
    });

    if (response.data?.url) {
      localStorage.removeItem('cart');
      window.location.href = response.data.url;
    } else {
      toast.error('Failed to start checkout. Please try again.');
      setLoading(false);
    }
  };

  if (cart.length === 0 && !success) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center p-4">
        <div className="text-center">
          <ShoppingBag className="w-16 h-16 mx-auto text-stone-300 mb-4" />
          <h2 className="text-2xl font-bold text-stone-800 mb-4">Your cart is empty</h2>
          <Link to={createPageUrl('Shop')}>
            <Button className="bg-emerald-600 hover:bg-emerald-700 rounded-full">
              Start Shopping
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  // Handle Stripe success redirect
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('success') === 'true') {
      setSuccess(true);
    }
  }, []);

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-emerald-50 to-stone-50 flex items-center justify-center p-4">
        <div className="text-center max-w-md w-full">
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-emerald-100 flex items-center justify-center">
            <Check className="w-10 h-10 text-emerald-600" />
          </div>
          <h2 className="text-3xl font-bold text-stone-800 mb-4">Payment Successful!</h2>
          <p className="text-stone-600 mb-6">
            Thank you for your order! Your payment was processed and your order is confirmed. You'll receive a confirmation email shortly.
          </p>
          <p className="text-stone-500 text-sm mb-8">
            Your order will be processed and shipped within 1-2 business days.
          </p>
          <Link to={createPageUrl('Shop')}>
            <Button className="bg-emerald-600 hover:bg-emerald-700 rounded-full px-8">
              Continue Shopping
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-stone-50 to-amber-50/30">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-stone-100">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to={createPageUrl('Home')} className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-amber-500 flex items-center justify-center">
              <Leaf className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-stone-800">EarthGoods</span>
          </Link>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <Link to={createPageUrl('Shop')} className="inline-flex items-center text-stone-600 hover:text-emerald-700 mb-8">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Continue Shopping
        </Link>

        <div className="grid md:grid-cols-5 gap-8">
          {/* Form */}
          <div className="md:col-span-3">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl">Checkout</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name *</Label>
                    <Input 
                      id="name"
                      value={form.customer_name}
                      onChange={(e) => setForm({...form, customer_name: e.target.value})}
                      className="h-12 rounded-xl"
                      placeholder="Your name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input 
                      id="email"
                      type="email"
                      value={form.customer_email}
                      onChange={(e) => setForm({...form, customer_email: e.target.value})}
                      className="h-12 rounded-xl"
                      placeholder="your@email.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="address">Shipping Address *</Label>
                    <Textarea 
                      id="address"
                      value={form.customer_address}
                      onChange={(e) => setForm({...form, customer_address: e.target.value})}
                      className="rounded-xl min-h-24"
                      placeholder="Street, City, State, ZIP"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="notes">Order Notes (optional)</Label>
                    <Textarea 
                      id="notes"
                      value={form.notes}
                      onChange={(e) => setForm({...form, notes: e.target.value})}
                      className="rounded-xl"
                      placeholder="Any special instructions..."
                    />
                  </div>

                  <div className="space-y-3">
                    <Label>Shipping Method</Label>
                    <RadioGroup value={shipping} onValueChange={setShipping} className="space-y-3">
                      <label className={`flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-colors ${shipping === 'standard' ? 'border-emerald-500 bg-emerald-50' : 'border-stone-200 hover:border-stone-300'}`}>
                        <RadioGroupItem value="standard" id="standard" />
                        <Truck className="w-5 h-5 text-stone-600" />
                        <div className="flex-1">
                          <p className="font-medium text-stone-800">Standard Shipping</p>
                          <p className="text-sm text-stone-500">5-7 business days</p>
                        </div>
                        <span className="font-semibold text-emerald-600">FREE</span>
                      </label>
                      <label className={`flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-colors ${shipping === 'overnight' ? 'border-emerald-500 bg-emerald-50' : 'border-stone-200 hover:border-stone-300'}`}>
                        <RadioGroupItem value="overnight" id="overnight" />
                        <Zap className="w-5 h-5 text-amber-500" />
                        <div className="flex-1">
                          <p className="font-medium text-stone-800">Overnight Shipping</p>
                          <p className="text-sm text-stone-500">Next business day</p>
                        </div>
                        <span className="font-semibold text-stone-800">+20%</span>
                      </label>
                    </RadioGroup>
                  </div>

                  {/* Referral Code */}
                  <div className="space-y-2">
                    <Label>Referral Code (optional)</Label>
                    {appliedCode ? (
                      <div className="flex items-center justify-between bg-emerald-50 border border-emerald-300 rounded-xl px-4 py-3">
                        <div className="flex items-center gap-2">
                          <Tag className="w-4 h-4 text-emerald-600" />
                          <span className="font-semibold text-emerald-700">{appliedCode.code}</span>
                          <Badge className="bg-emerald-100 text-emerald-700 border-0">-{appliedCode.discount_percent}% off</Badge>
                        </div>
                        <button type="button" onClick={removeCode} className="text-stone-400 hover:text-stone-600">
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex gap-2">
                        <Input
                          value={refInput}
                          onChange={(e) => { setRefInput(e.target.value.toUpperCase()); setRefError(''); }}
                          placeholder="Enter referral code"
                          className="h-12 rounded-xl uppercase"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => applyCode()}
                          disabled={refLoading || !refInput.trim()}
                          className="rounded-xl px-5 flex-shrink-0"
                        >
                          {refLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Apply'}
                        </Button>
                      </div>
                    )}
                    {refError && <p className="text-sm text-red-500">{refError}</p>}
                  </div>

                  <Button 
                    type="submit" 
                    disabled={loading || isInIframe}
                    className="w-full h-14 rounded-full bg-emerald-600 hover:bg-emerald-700 text-lg font-semibold"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Redirecting to Stripe...
                      </>
                    ) : (
                      `Pay with Card — $${grandTotal.toFixed(2)}`
                    )}
                  </Button>

                  {/* PayPal alternative */}
                  <div className="relative flex items-center gap-3">
                    <div className="flex-1 border-t border-stone-200" />
                    <span className="text-xs text-stone-400">or pay with</span>
                    <div className="flex-1 border-t border-stone-200" />
                  </div>
                  <a
                    href={`https://www.paypal.com/paypalme/tracieruth281/${grandTotal.toFixed(2)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full"
                    onClick={() => {
                      if (!form.customer_name || !form.customer_email || !form.customer_address) {
                        toast.error('Please fill in your details above first');
                        return;
                      }
                    }}
                  >
                    <button
                      type="button"
                      className="w-full h-12 rounded-full text-base font-bold flex items-center justify-center gap-3"
                      style={{background: '#003087', color: '#fff'}}
                    >
                      <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white"><path d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944.901C5.026.382 5.474 0 5.998 0h7.46c2.57 0 4.578.543 5.69 1.81 1.01 1.15 1.304 2.42 1.012 4.287-.023.143-.047.288-.077.437-.983 5.05-4.349 6.797-8.647 6.797h-2.19c-.524 0-.968.382-1.05.9l-1.12 7.106zm14.146-14.42a3.35 3.35 0 0 0-.607-.541c-.013.076-.026.175-.041.254-.59 3.025-2.566 6.082-8.558 6.082H9.825l-1.273 8.05h3.51l.922-5.832c.082-.518.526-.9 1.05-.9h.663c4.299 0 7.664-1.747 8.647-6.797.021-.106.04-.21.057-.316z"/></svg>
                      Pay ${grandTotal.toFixed(2)} with PayPal
                    </button>
                  </a>
                  {isInIframe && (
                    <p className="text-xs text-amber-600 text-center">⚠️ Stripe checkout only works in the published app. Use PayPal or open the app in a new tab.</p>
                  )}
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Order Summary */}
          <div className="md:col-span-2">
            <Card className="border-0 shadow-lg sticky top-24">
              <CardHeader>
                <CardTitle className="text-lg">Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {cart.map(item => (
                  <div key={item.id} className="flex gap-3">
                    <div className="w-14 h-14 rounded-lg bg-stone-100 overflow-hidden flex-shrink-0">
                      {item.image_url ? (
                        <img src={item.image_url} alt={item.title} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Leaf className="w-5 h-5 text-stone-300" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-stone-800 truncate text-sm">{item.title}</p>
                      <p className="text-stone-500 text-sm">Qty: {item.quantity}</p>
                    </div>
                    <p className="font-semibold text-stone-800">${(item.price * item.quantity).toFixed(2)}</p>
                  </div>
                ))}

                <div className="border-t border-stone-200 pt-4 mt-4 space-y-2">
                  <div className="flex justify-between text-stone-600">
                    <span>Subtotal</span>
                    <span>${total.toFixed(2)}</span>
                  </div>
                  {appliedCode && (
                    <div className="flex justify-between text-emerald-600 font-medium">
                      <span className="flex items-center gap-1">
                        <Tag className="w-3 h-3" />
                        Referral Discount ({appliedCode.discount_percent}%)
                      </span>
                      <span>-${discountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-stone-600">
                    <span className="flex items-center gap-1">
                      Platform Fee 
                      <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">3%</span>
                    </span>
                    <span>${fee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-stone-600">
                    <span>Shipping</span>
                    <span>{shipping === 'overnight' ? `$${shippingCost.toFixed(2)}` : 'FREE'}</span>
                  </div>
                  <div className="flex justify-between text-xl font-bold text-stone-800 pt-2">
                    <span>Total</span>
                    <span>${grandTotal.toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}