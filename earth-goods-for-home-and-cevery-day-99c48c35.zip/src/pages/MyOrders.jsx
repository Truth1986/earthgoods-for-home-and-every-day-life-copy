import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Leaf, ShoppingBag, Truck, Download, Eye, Package, ArrowLeft, MapPin, Calendar, DollarSign, FileText } from "lucide-react";
import moment from 'moment';
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";

const statusConfig = {
  pending: {
    label: 'Order Placed',
    color: 'bg-yellow-100 text-yellow-800',
    icon: Package,
  },
  paid: {
    label: 'Payment Confirmed',
    color: 'bg-blue-100 text-blue-800',
    icon: Package,
  },
  shipped: {
    label: 'Shipped',
    color: 'bg-purple-100 text-purple-800',
    icon: Truck,
  },
  delivered: {
    label: 'Delivered',
    color: 'bg-green-100 text-green-800',
    icon: Package,
  },
};

function generateInvoicePDF(order) {
  // Simple invoice generation - can be enhanced with a PDF library
  const invoiceContent = `
INVOICE

Order #${order.id.slice(0, 8).toUpperCase()}
Date: ${moment(order.created_date).format('MMM DD, YYYY')}
Status: ${order.status.toUpperCase()}

CUSTOMER INFORMATION
${order.customer_name}
${order.customer_email}
${order.customer_address}

ITEMS ORDERED
${order.items?.map((item, idx) => `
${idx + 1}. ${item.title}
   Quantity: ${item.quantity}
   Price: $${item.price.toFixed(2)} each
   Subtotal: $${(item.price * item.quantity).toFixed(2)}
`).join('')}

PAYMENT SUMMARY
Subtotal: $${(order.total * 0.97).toFixed(2)}
Platform Fee (3%): $${((order.total * 0.03).toFixed(2))}
Total: $${order.total.toFixed(2)}

Thank you for your purchase!
`;

  // Create blob and download
  const blob = new Blob([invoiceContent], { type: 'text/plain' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `invoice-${order.id.slice(0, 8)}.txt`;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
  
  toast.success('Invoice downloaded');
}

export default function MyOrders() {
  const [expandedOrderId, setExpandedOrderId] = useState(null);

  const { data: user } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: orders = [], isLoading } = useQuery({
    queryKey: ['my-orders', user?.email],
    queryFn: () => base44.entities.Order.filter({ customer_email: user.email }, '-created_date'),
    enabled: !!user?.email,
  });

  const deliveredOrders = orders.filter(o => o.status === 'delivered');
  const activeOrders = orders.filter(o => o.status !== 'delivered');

  return (
    <div className="min-h-screen bg-gradient-to-b from-stone-50 to-amber-50/30">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-stone-100">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to={createPageUrl('Home')} className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-amber-500 flex items-center justify-center">
              <Leaf className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-stone-800">EarthGoods</span>
          </Link>
          <Link to={createPageUrl('Home')}>
            <Button variant="outline" className="rounded-full">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back Home
            </Button>
          </Link>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Page Title */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-stone-800 mb-2">My Orders</h1>
          <p className="text-stone-600">Track shipments, view order history, and download invoices</p>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin w-8 h-8 border-4 border-emerald-600 border-t-transparent rounded-full" />
          </div>
        ) : orders.length === 0 ? (
          <Card className="bg-white border-stone-200">
            <CardContent className="p-12 text-center">
              <ShoppingBag className="w-16 h-16 mx-auto text-stone-300 mb-4" />
              <h3 className="text-xl font-semibold text-stone-700 mb-2">No orders yet</h3>
              <p className="text-stone-500 mb-6">Once you place an order, you can track it here</p>
              <Link to={createPageUrl('Shop')}>
                <Button className="bg-emerald-600 hover:bg-emerald-700 rounded-full">
                  Start Shopping
                </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <Tabs defaultValue="active" className="space-y-6">
            <TabsList className="bg-white border border-stone-200 p-1 rounded-full">
              <TabsTrigger value="active" className="rounded-full data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                <Truck className="w-4 h-4 mr-2" />
                Active Orders ({activeOrders.length})
              </TabsTrigger>
              <TabsTrigger value="history" className="rounded-full data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                <FileText className="w-4 h-4 mr-2" />
                Order History ({deliveredOrders.length})
              </TabsTrigger>
            </TabsList>

            {/* Active Orders Tab */}
            <TabsContent value="active" className="space-y-6">
              {activeOrders.length === 0 ? (
                <Card className="bg-white border-stone-200">
                  <CardContent className="p-12 text-center">
                    <Truck className="w-16 h-16 mx-auto text-stone-300 mb-4" />
                    <p className="text-stone-600">No active orders</p>
                  </CardContent>
                </Card>
              ) : (
                activeOrders.map(order => (
                  <Card key={order.id} className="bg-white border-stone-200 overflow-hidden">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <CardTitle className="text-lg">Order #{order.id.slice(0, 8).toUpperCase()}</CardTitle>
                          <div className="flex items-center gap-4 text-sm text-stone-500 mt-2">
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {moment(order.created_date).format('MMM DD, YYYY')}
                            </div>
                            <div className="flex items-center gap-1">
                              <DollarSign className="w-4 h-4" />
                              ${order.total?.toFixed(2)}
                            </div>
                          </div>
                        </div>
                        <Badge className={`${statusConfig[order.status]?.color || 'bg-gray-100 text-gray-800'} border-0`}>
                          {statusConfig[order.status]?.label || order.status}
                        </Badge>
                      </div>
                    </CardHeader>

                    {/* Progress Bar */}
                    <CardContent className="pb-3">
                      <div className="flex items-center gap-2 mb-4">
                        {['pending', 'paid', 'shipped', 'delivered'].map((status, idx) => {
                          const steps = ['pending', 'paid', 'shipped', 'delivered'];
                          const currentIdx = steps.indexOf(order.status);
                          const isDone = idx <= currentIdx;
                          return (
                            <React.Fragment key={status}>
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                                isDone ? 'bg-emerald-600 text-white' : 'bg-stone-200 text-stone-600'
                              }`}>
                                {idx + 1}
                              </div>
                              {idx < 3 && <div className={`flex-1 h-1 ${idx < currentIdx ? 'bg-emerald-600' : 'bg-stone-200'}`} />}
                            </React.Fragment>
                          );
                        })}
                      </div>
                    </CardContent>

                    {/* Items */}
                    <CardContent className="pb-3 border-t border-stone-100 pt-3">
                      <p className="text-sm font-medium text-stone-700 mb-2">Items:</p>
                      {order.items?.map((item, idx) => (
                        <div key={idx} className="flex justify-between text-sm text-stone-600 py-1">
                          <span>{item.quantity}× {item.title}</span>
                          <span>${(item.price * item.quantity).toFixed(2)}</span>
                        </div>
                      ))}
                    </CardContent>

                    {/* Shipping Address */}
                    {order.customer_address && (
                      <CardContent className="pb-3 border-t border-stone-100 pt-3">
                        <p className="text-sm font-medium text-stone-700 mb-2">Shipping To:</p>
                        <div className="flex items-start gap-2 text-sm text-stone-600 bg-stone-50 rounded-lg p-3">
                          <MapPin className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                          <span>{order.customer_address}</span>
                        </div>
                      </CardContent>
                    )}

                    {/* Actions */}
                    <CardContent className="border-t border-stone-100 pt-3">
                      <div className="flex gap-2">
                        <button
                          onClick={() => setExpandedOrderId(expandedOrderId === order.id ? null : order.id)}
                          className="flex-1 px-4 py-2 text-sm font-medium text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors flex items-center justify-center gap-2"
                        >
                          <Eye className="w-4 h-4" />
                          {expandedOrderId === order.id ? 'Hide Details' : 'View Details'}
                        </button>
                        <button
                          onClick={() => generateInvoicePDF(order)}
                          className="px-4 py-2 text-sm font-medium text-stone-700 hover:bg-stone-100 rounded-lg transition-colors flex items-center justify-center gap-2 border border-stone-200"
                        >
                          <Download className="w-4 h-4" />
                          Invoice
                        </button>
                      </div>
                    </CardContent>

                    {/* Expandable Details */}
                    {expandedOrderId === order.id && (
                      <CardContent className="border-t border-stone-100 pt-4 bg-stone-50">
                        <div className="space-y-3 text-sm">
                          <div>
                            <p className="text-stone-600">Order Notes:</p>
                            <p className="text-stone-800 mt-1">{order.notes || 'No notes'}</p>
                          </div>
                          <div>
                            <p className="text-stone-600">Status Updated:</p>
                            <p className="text-stone-800 mt-1">{moment(order.updated_date).format('MMM DD, YYYY h:mm A')}</p>
                          </div>
                        </div>
                      </CardContent>
                    )}
                  </Card>
                ))
              )}
            </TabsContent>

            {/* Order History Tab */}
            <TabsContent value="history" className="space-y-6">
              {deliveredOrders.length === 0 ? (
                <Card className="bg-white border-stone-200">
                  <CardContent className="p-12 text-center">
                    <FileText className="w-16 h-16 mx-auto text-stone-300 mb-4" />
                    <p className="text-stone-600">No delivered orders yet</p>
                  </CardContent>
                </Card>
              ) : (
                deliveredOrders.map(order => (
                  <Card key={order.id} className="bg-white border-stone-200 hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="font-semibold text-stone-800">Order #{order.id.slice(0, 8).toUpperCase()}</h3>
                            <Badge className="bg-green-100 text-green-800 border-0">Delivered</Badge>
                          </div>
                          <div className="flex flex-wrap gap-4 text-sm text-stone-600">
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {moment(order.created_date).format('MMM DD, YYYY')}
                            </div>
                            <div className="flex items-center gap-1">
                              <Package className="w-4 h-4" />
                              {order.items?.length || 0} items
                            </div>
                            <div className="flex items-center gap-1">
                              <DollarSign className="w-4 h-4" />
                              ${order.total?.toFixed(2)}
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => setExpandedOrderId(expandedOrderId === order.id ? null : order.id)}
                            className="px-4 py-2 text-sm font-medium text-stone-700 hover:bg-stone-100 rounded-lg transition-colors border border-stone-200"
                          >
                            {expandedOrderId === order.id ? 'Hide' : 'View'}
                          </button>
                          <button
                            onClick={() => generateInvoicePDF(order)}
                            className="px-4 py-2 text-sm font-medium text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors flex items-center gap-2 border border-emerald-200"
                          >
                            <Download className="w-4 h-4" />
                            Invoice
                          </button>
                        </div>
                      </div>

                      {expandedOrderId === order.id && (
                        <div className="mt-4 pt-4 border-t border-stone-200 space-y-3">
                          {order.items?.map((item, idx) => (
                            <div key={idx} className="flex justify-between text-sm">
                              <span className="text-stone-700">{item.quantity}× {item.title}</span>
                              <span className="font-medium text-stone-800">${(item.price * item.quantity).toFixed(2)}</span>
                            </div>
                          ))}
                          <div className="pt-3 border-t border-stone-200 flex justify-between font-medium">
                            <span>Total:</span>
                            <span>${order.total?.toFixed(2)}</span>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))
              )}
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  );
}