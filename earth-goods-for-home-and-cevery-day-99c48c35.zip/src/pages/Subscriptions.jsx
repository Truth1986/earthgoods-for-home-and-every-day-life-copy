import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Leaf, ArrowLeft, Check, Zap, Leaf as LeafIcon, Droplet, Sprout, ChevronDown } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";

const categoryIcons = {
  herbs: Sprout,
  essentials: Zap,
  oils: Droplet,
  seasonal: LeafIcon,
};

const categoryLabels = {
  herbs: 'Monthly Herbs',
  essentials: 'Essentials Kit',
  oils: 'Curated Oils',
  seasonal: 'Seasonal Boxes',
};

export default function Subscriptions() {
  const [user, setUser] = useState(null);

  useQuery({
    queryKey: ['current-user'],
    queryFn: async () => {
      const u = await base44.auth.me();
      setUser(u);
      return u;
    },
  });

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ['subscription-plans'],
    queryFn: () => base44.entities.SubscriptionPlan.filter({ is_active: true }, '-featured'),
  });

  const { data: activeSubscriptions = [] } = useQuery({
    queryKey: ['my-subscriptions', user?.email],
    queryFn: () => base44.entities.Subscription.filter({ 
      customer_email: user.email,
      status: 'active'
    }),
    enabled: !!user?.email,
  });

  const handleSubscribe = async (plan) => {
    if (!user) {
      await base44.auth.redirectToLogin(`/Subscriptions?plan=${plan.id}`);
      return;
    }

    // Check if already subscribed
    if (activeSubscriptions.some(sub => sub.plan_id === plan.id)) {
      toast.error('You already have an active subscription to this plan');
      return;
    }

    try {
      // Create checkout session for subscription
      const response = await base44.functions.invoke('createSubscriptionCheckout', {
        plan_id: plan.id,
        plan_name: plan.name,
        monthly_price: plan.monthly_price,
        discount_percent: plan.discount_percent,
        stripe_price_id: plan.stripe_price_id,
        customer_email: user.email,
      });

      if (response.data?.url) {
        window.location.href = response.data.url;
      } else {
        toast.error('Failed to start subscription. Please try again.');
      }
    } catch (error) {
      toast.error('Error: ' + error.message);
    }
  };

  const isInIframe = window.self !== window.top;

  return (
    <div className="min-h-screen bg-gradient-to-b from-stone-50 to-amber-50/30">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-stone-100">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to={createPageUrl('Home')} className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-amber-500 flex items-center justify-center">
              <Leaf className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-stone-800">EarthGoods</span>
          </Link>
          <Link to={createPageUrl('Shop')} className="inline-flex items-center text-stone-600 hover:text-emerald-700">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Shop
          </Link>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-16">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <Badge className="bg-emerald-100 text-emerald-800 border-0 mb-4">
            Subscribe & Save
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-stone-800 mb-4">
            Monthly Deliveries
            <br />
            <span className="text-emerald-600">Curated Just for You</span>
          </h1>
          <p className="text-xl text-stone-600 max-w-2xl mx-auto">
            Get seasonal herbs, homesteading essentials, and curated oil kits delivered monthly 
            with exclusive subscriber discounts.
          </p>
        </div>

        {/* Active Subscriptions */}
        {activeSubscriptions.length > 0 && (
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-stone-800 mb-6">Your Subscriptions</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {activeSubscriptions.map(sub => (
                <Card key={sub.id} className="border-emerald-200 bg-emerald-50">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>{sub.plan_name}</span>
                      <Badge className="bg-emerald-600 text-white border-0">Active</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <p className="text-sm text-stone-600">Monthly Price</p>
                      <p className="text-2xl font-bold text-stone-800">
                        ${sub.monthly_price.toFixed(2)}
                        {sub.discount_percent > 0 && (
                          <span className="text-sm text-emerald-600 ml-2">({sub.discount_percent}% off)</span>
                        )}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-stone-600">Next Delivery</p>
                      <p className="font-semibold text-stone-800">{sub.next_billing_date}</p>
                    </div>
                    <div>
                      <p className="text-sm text-stone-600">Total Billed</p>
                      <p className="font-semibold text-stone-800">${sub.total_billed.toFixed(2)} ({sub.billing_count} deliveries)</p>
                    </div>
                    <Link to={createPageUrl('CustomerDashboard')}>
                      <Button variant="outline" className="w-full rounded-full">
                        Manage Subscription
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Plans Grid */}
        <div>
          <h2 className="text-2xl font-bold text-stone-800 mb-6">Choose Your Plan</h2>
          
          {isLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="bg-white rounded-2xl h-96 animate-pulse" />
              ))}
            </div>
          ) : plans.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {plans.map(plan => {
                const Icon = categoryIcons[plan.category];
                const isSubscribed = activeSubscriptions.some(sub => sub.plan_id === plan.id);
                
                return (
                  <Card key={plan.id} className={`relative overflow-hidden transition-all ${
                    plan.featured ? 'ring-2 ring-emerald-600 md:scale-105' : 'border-stone-200'
                  }`}>
                    {plan.featured && (
                      <Badge className="absolute top-4 right-4 bg-emerald-600 text-white border-0">
                        Most Popular
                      </Badge>
                    )}

                    {plan.image_url && (
                      <div className="h-32 bg-stone-100 overflow-hidden">
                        <img src={plan.image_url} alt={plan.name} className="w-full h-full object-cover" />
                      </div>
                    )}

                    <CardHeader>
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center">
                          <Icon className="w-4 h-4 text-emerald-700" />
                        </div>
                        <Badge className="bg-stone-100 text-stone-800 border-0 text-xs">
                          {categoryLabels[plan.category]}
                        </Badge>
                      </div>
                      <CardTitle>{plan.name}</CardTitle>
                    </CardHeader>

                    <CardContent className="space-y-4">
                      <div>
                        <p className="text-sm text-stone-500 uppercase tracking-wide">Per Month</p>
                        <p className="text-3xl font-bold text-stone-800">
                          ${plan.monthly_price.toFixed(2)}
                        </p>
                        {plan.discount_percent > 0 && (
                          <p className="text-sm text-emerald-600 mt-1">
                            Save {plan.discount_percent}% vs one-time
                          </p>
                        )}
                      </div>

                      {plan.description && (
                        <p className="text-sm text-stone-600 leading-relaxed">
                          {plan.description}
                        </p>
                      )}

                      {plan.included_items?.length > 0 && (
                        <div className="space-y-2">
                          <p className="text-sm font-semibold text-stone-700">Includes:</p>
                          <ul className="space-y-1">
                            {plan.included_items.map((item, idx) => (
                              <li key={idx} className="flex items-start gap-2 text-sm text-stone-600">
                                <Check className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                                <span>{item.item_name}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {plan.delivery_day && (
                        <p className="text-xs text-stone-500 bg-stone-50 rounded-lg p-2">
                          📦 Delivered on the {plan.delivery_day}th of each month
                        </p>
                      )}

                      <Button
                        onClick={() => handleSubscribe(plan)}
                        disabled={isInIframe || isSubscribed}
                        className={`w-full rounded-full h-12 font-semibold ${
                          isSubscribed
                            ? 'bg-stone-200 text-stone-600 cursor-not-allowed'
                            : plan.featured
                            ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                            : 'bg-stone-100 text-stone-800 hover:bg-stone-200'
                        }`}
                      >
                        {isSubscribed ? '✓ Subscribed' : 'Subscribe with Card'}
                      </Button>

                      <a
                        href={`https://www.paypal.com/paypalme/tracieruth281/${(plan.monthly_price).toFixed(2)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block w-full"
                        onClick={(e) => {
                          if (!user) {
                            e.preventDefault();
                            toast.error('Please sign in first');
                          }
                        }}
                      >
                        <button
                          type="button"
                          disabled={isSubscribed}
                          className="w-full h-12 rounded-full text-base font-semibold flex items-center justify-center gap-3 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                          style={{background: isSubscribed ? '#ccc' : '#003087', color: '#fff'}}
                        >
                          <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white"><path d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944.901C5.026.382 5.474 0 5.998 0h7.46c2.57 0 4.578.543 5.69 1.81 1.01 1.15 1.304 2.42 1.012 4.287-.023.143-.047.288-.077.437-.983 5.05-4.349 6.797-8.647 6.797h-2.19c-.524 0-.968.382-1.05.9l-1.12 7.106zm14.146-14.42a3.35 3.35 0 0 0-.607-.541c-.013.076-.026.175-.041.254-.59 3.025-2.566 6.082-8.558 6.082H9.825l-1.273 8.05h3.51l.922-5.832c.082-.518.526-.9 1.05-.9h.663c4.299 0 7.664-1.747 8.647-6.797.021-.106.04-.21.057-.316z"/></svg>
                          Subscribe with PayPal
                        </button>
                      </a>

                      {isInIframe && (
                        <p className="text-xs text-amber-600 text-center mt-2">
                          ⚠️ Subscriptions work in the published app only
                        </p>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card className="bg-white border-stone-200">
              <CardContent className="p-12 text-center">
                <Leaf className="w-16 h-16 mx-auto text-stone-300 mb-4" />
                <h3 className="text-xl font-semibold text-stone-700 mb-2">No plans available</h3>
                <p className="text-stone-500">Check back soon for subscription options!</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* FAQ Section */}
        <div className="mt-16 max-w-3xl mx-auto">
          <h2 className="text-2xl font-bold text-stone-800 mb-8">Common Questions</h2>
          <div className="space-y-4">
            {[
              {
                q: "How does billing work?",
                a: "You'll be billed monthly on the date you subscribe. You can cancel anytime with no penalties."
              },
              {
                q: "Can I change or pause my subscription?",
                a: "Yes! Visit your account dashboard to manage, pause, or cancel your subscription at any time."
              },
              {
                q: "What if I miss a delivery?",
                a: "Contact us and we'll reschedule your delivery at no extra cost."
              },
              {
                q: "Are there seasonal variations?",
                a: "Yes! Our seasonal boxes change monthly with what's in season for the best homesteading experience."
              },
            ].map((faq, idx) => (
              <Card key={idx} className="bg-white border-stone-200">
                <CardHeader>
                  <CardTitle className="text-lg">{faq.q}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-stone-600">{faq.a}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}